#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <math.h>

#define POINTS 100000
#define K 5
#define ITERATIONS 20

typedef struct {
    double x, y;
    int cluster;
} Point;

int main() {
    Point *points = malloc(POINTS * sizeof(Point));
    Point centroids[K];
    int num_threads;

    printf("Enter number of threads: ");
    scanf("%d", &num_threads);

    // 1. Initialization (Sequential)
    for (int i = 0; i < POINTS; i++) {
        points[i].x = (double)rand() / RAND_MAX;
        points[i].y = (double)rand() / RAND_MAX;
    }
    for (int i = 0; i < K; i++) {
        centroids[i] = points[i]; // Simple initial pick
    }

    double start = omp_get_wtime();

    // 2. Main K-Means Loop
    for (int iter = 0; iter < ITERATIONS; iter++) {
        
        // --- STUDENT TASK: Parallelize this Assignment Phase ---
        // Goal: For each point, find the nearest centroid
        #pragma omp parallel for num_threads(num_threads)
        for (int i = 0; i < POINTS; i++) {
            double min_dist = 1e10;
            for (int j = 0; j < K; j++) {
                double dist = sqrt(pow(points[i].x - centroids[j].x, 2) + 
                                   pow(points[i].y - centroids[j].y, 2));
                if (dist < min_dist) {
                    min_dist = dist;
                    points[i].cluster = j;
                }
            }
        }

        // --- STUDENT TASK: Parallelize this Update Phase ---
        // Goal: Recompute centroids based on the mean of assigned points
        // Hint: Use reduction or critical sections to avoid race conditions
        double sum_x[K], sum_y[K];
        int count[K];
        for (int j = 0; j < K; j++) {
            sum_x[j] = 0.0;
            sum_y[j] = 0.0;
            count[j] = 0;
        }

        #pragma omp parallel num_threads(num_threads)
        {
            double l_sum_x[K], l_sum_y[K];
            int l_count[K];
            for (int j = 0; j < K; j++) {
                l_sum_x[j] = 0.0;
                l_sum_y[j] = 0.0;
                l_count[j] = 0;
            }

            #pragma omp for
            for (int i = 0; i < POINTS; i++) {
                int c = points[i].cluster;
                l_sum_x[c] += points[i].x;
                l_sum_y[c] += points[i].y;
                l_count[c]++;
            }

            for (int j = 0; j < K; j++) {
                #pragma omp atomic
                sum_x[j] += l_sum_x[j];
                #pragma omp atomic
                sum_y[j] += l_sum_y[j];
                #pragma omp atomic
                count[j] += l_count[j];
            }
        }

        for (int j = 0; j < K; j++) {
            if (count[j] > 0) {
                centroids[j].x = sum_x[j] / count[j];
                centroids[j].y = sum_y[j] / count[j];
            }
        }
    }

    double end = omp_get_wtime();
    printf("Clustering completed in %.4f seconds\n", end - start);

    free(points);
    return 0;
}
