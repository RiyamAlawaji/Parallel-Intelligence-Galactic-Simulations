#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <math.h>

#define N 1000
#define DT 0.01
#define STEPS 100
#define G 1.0
#define EPS 1e-9

typedef struct {
    double x, y, vx, vy;
} Particle;

int main(int argc, char** argv) {
    int rank, size;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int local_n = N / size;

    Particle *local_particles = malloc(local_n * sizeof(Particle));
    Particle *all_particles = malloc(N * sizeof(Particle));

    if (rank == 0) {
        for (int i = 0; i < N; i++) {
            all_particles[i].x = (double)rand() / RAND_MAX;
            all_particles[i].y = (double)rand() / RAND_MAX;
            all_particles[i].vx = 0.0;
            all_particles[i].vy = 0.0;
        }
    }

    MPI_Scatter(all_particles, local_n * 4, MPI_DOUBLE,
                local_particles, local_n * 4, MPI_DOUBLE,
                0, MPI_COMM_WORLD);

    double start = MPI_Wtime();

    for (int step = 0; step < STEPS; step++) {

        MPI_Allgather(local_particles, local_n * 4, MPI_DOUBLE,
                      all_particles, local_n * 4, MPI_DOUBLE,
                      MPI_COMM_WORLD);

        for (int i = 0; i < local_n; i++) {
            double fx = 0.0;
            double fy = 0.0;

            for (int j = 0; j < N; j++) {
                double dx = all_particles[j].x - local_particles[i].x;
                double dy = all_particles[j].y - local_particles[i].y;

                double dist_sq = dx * dx + dy * dy + EPS;
                double dist = sqrt(dist_sq);

                double force = G / dist_sq;

                fx += force * dx / dist;
                fy += force * dy / dist;
            }

            local_particles[i].vx += fx * DT;
            local_particles[i].vy += fy * DT;

            local_particles[i].x += local_particles[i].vx * DT;
            local_particles[i].y += local_particles[i].vy * DT;
        }
    }

    double end = MPI_Wtime();

    if (rank == 0) {
        printf("N-Body Simulation finished in %.4f seconds\n", end - start);
        printf("Particles: %d\n", N);
        printf("Steps: %d\n", STEPS);
        printf("Processes: %d\n", size);
    }

    free(local_particles);
    free(all_particles);

    MPI_Finalize();
    return 0;
}