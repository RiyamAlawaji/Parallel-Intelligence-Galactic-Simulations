#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 1000

typedef struct {
    double x, y;
    double vx, vy;
    double mass;
} Body;

Body bodies[N];

void initialize() {
    for (int i = 0; i < N; i++) {
        bodies[i].x = rand() % 100;
        bodies[i].y = rand() % 100;
        bodies[i].vx = bodies[i].vy = 0;
        bodies[i].mass = 1.0;
    }
}

void compute_forces() {
    for (int i = 0; i < N; i++) {
        double fx = 0, fy = 0;

        for (int j = 0; j < N; j++) {
            if (i == j) continue;

            double dx = bodies[j].x - bodies[i].x;
            double dy = bodies[j].y - bodies[i].y;
            double dist = sqrt(dx*dx + dy*dy) + 1e-5;

            double F = (bodies[i].mass * bodies[j].mass) / (dist * dist);

            fx += F * dx / dist;
            fy += F * dy / dist;
        }

        bodies[i].vx += fx;
        bodies[i].vy += fy;
    }
}

int main() {
    initialize();
    compute_forces();

    printf("Simulation done.\n");
    return 0;
}